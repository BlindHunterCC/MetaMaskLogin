
import sys
import pandas
from selenium import webdriver
from selenium.webdriver.common.by import By

sys.path.append('..')
from common.browser.bit_api import open
from common.commonUtils import wait

def metamaskLogin(browser_id):
    driver = open(browser_id)
    driver.switch_to.new_window()
    wait(1)
    driver.get('chrome-extension://nkbihfbeogaeaoehlefnkodbefgpgknn/popup.html')
    # 从csv中查找密码
    cols = pandas.read_csv('../data/browser_info.csv', usecols=["browser_id", "meta_passwd"])
    # 等待加载完成
    wait(1)
    if 'MetaMask' == driver.title:
        try:
            # 获取密码输入框
            metamaskPassWdInput = driver.find_element(By.ID, 'password')
            # 遍历DataFrame的每一行
            for index, row in cols.iterrows():
                # row是一个pandas的Series对象，表示csv文件的一行数据
                if row.get('browser_id') == browser_id:
                    metamaskPassWdInput.send_keys(row.get('meta_passwd'))
                    break
            # metamask确认登录
            wait(1)
            driver.find_element(By.CLASS_NAME, 'btn--rounded').click()
            print('metamask已自动登录，当前的浏览器id为：' + browser_id)
        except:
            print('metamask没有登录选项，当前的浏览器id为：' + browser_id)

#metamaskLogin("294c955096c945a39a60c20280149af8")