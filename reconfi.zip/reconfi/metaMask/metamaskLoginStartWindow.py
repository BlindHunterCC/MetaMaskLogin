import sys
import random
import pandas
import asyncio
from metamaskLogin import metamaskLogin
from asyncio.windows_events import WindowsSelectorEventLoopPolicy

sys.path.append('..')
from common.browser.bit_api import getBrowserListId

async def opt():
    #browser_group_id = pandas.read_csv('../data/browser_group.csv', usecols=["browser_group"])
    winOpenFuncs = []

    #for index, row in browser_group_id.iterrows():
    #browser_group_id = "2c9bc0618e1bf6dd018e224e09131de6"
    browser_group_id = input("请输入浏览器GroupID:\n")
        #browser_list = getBrowserListId(row.get('browser_group'))
    browser_list = getBrowserListId(browser_group_id)

    for browser in browser_list:
            winOpenFuncs.append(metamaskLogin(browser))

    try:
        await asyncio.gather(*winOpenFuncs)
        #loop.run_until_complete(asyncio.wait(winOpenFuncs))

    except:
        print('当前窗口打开错误，浏览器id为：' + browser)

if __name__ == '__main__':
    asyncio.set_event_loop_policy(WindowsSelectorEventLoopPolicy())
    asyncio.run(opt())