import sys
import random
import pandas
from time import sleep
from metamaskLogin import metamaskLogin
from concurrent.futures import ThreadPoolExecutor

sys.path.append('..')
from common.browser.bit_api import getBrowserListId


browser_groups = pandas.read_csv('../data/browser_group.csv', usecols=["browser_group"])
for index, row in browser_groups.iterrows():
#browser_group_id = "2c9bc0618e1bf6dd018e224e487a1f67"
    browser_list = getBrowserListId(row.get('browser_group'))
# 几个浏览器环境，创建几个线程
#executor = ThreadPoolExecutor(len(browser_list))
#for browser in browser_list:
#    executor.submit(metamaskLogin, browser, 1)
#    sleep(round(random.uniform(10, 20), 1))
#executor.shutdown()

    for browser in browser_list:
    # 打开太快了，电脑扛不住
        try:
            metamaskLogin(browser)
            sleep(7)
        except:
            print('当前窗口打开错误，浏览器id为：' + browser)