import os
import sys
import pandas
import pandas.io.clipboard as cb
from selenium.webdriver.common.by import By
from selenium import webdriver

sys.path.append('..')
from common.browser.bit_api import open
from common.commonUtils import wait,generate_password


# metamask初始化
def metamaskInit(browser_id):
    driver = open(browser_id)
    driver.get('chrome-extension://nkbihfbeogaeaoehlefnkodbefgpgknn/home.html#onboarding/welcome')
    wait(8)
    # 勾选同意协议
    driver.find_element(By.ID, 'onboarding__terms-checkbox').click()
    wait(1)
    # 确认创建
    createBtn = driver.find_element(By.CSS_SELECTOR, '[data-testid="onboarding-create-wallet"]')
    createBtn.click()
    # 点击我同意
    wait(1)
    # 确认创建
    agreeBtn = driver.find_element(By.CSS_SELECTOR, '[data-testid="metametrics-i-agree"]')
    agreeBtn.click()
    # 输入密码,生产八位随机密码
    meta_passwd = generate_password(8)
    print('browser_id为:' + browser_id + '的窗口密码为：' + meta_passwd)
    passwdInput = driver.find_element(By.CSS_SELECTOR, '[data-testid="create-password-new"]')
    passwdInput.send_keys(meta_passwd)
    wait(1)
    # 确认密码
    confirmInput = driver.find_element(By.CSS_SELECTOR, '[data-testid="create-password-confirm"]')
    confirmInput.send_keys(meta_passwd)
    # 同意协议
    driver.find_element(By.CSS_SELECTOR, '[data-testid="create-password-terms"]').click()
    # 创建钱包
    wait(1)
    createWallet = driver.find_element(By.CSS_SELECTOR, '[data-testid="create-password-wallet"]')
    createWallet.click()
    # 保护我的钱包
    wait(2)
    driver.find_element(By.CSS_SELECTOR, '[data-testid="secure-wallet-recommended"]').click()
    # 显示助记词
    wait(1)
    driver.find_element(By.CSS_SELECTOR, '[data-testid="recovery-phrase-reveal"]').click()
    # 点击复制到剪切板
    driver.find_element(By.CLASS_NAME, 'recovery-phrase__footer__copy-and-hide__button__copy-to-clipboard').click()
    # 获取剪切板内容
    meta_recovery = cb.paste()
    print("助记词" + browser_id + meta_recovery)
    wait(1)
    # 点击下一步
    driver.find_element(By.CSS_SELECTOR, '[data-testid="recovery-phrase-next"]').click()
    recoveryList = meta_recovery.split(' ')
    # 3
    wait(1)
    driver.find_element(By.CSS_SELECTOR, '[data-testid="recovery-phrase-input-2"]').send_keys(recoveryList[2])
    # 4
    wait(1)
    driver.find_element(By.CSS_SELECTOR, '[data-testid="recovery-phrase-input-3"]').send_keys(recoveryList[3])
    # 8
    wait(1)
    driver.find_element(By.CSS_SELECTOR, '[data-testid="recovery-phrase-input-7"]').send_keys(recoveryList[7])
    # 确认
    wait(1)
    driver.find_element(By.CSS_SELECTOR, '[data-testid="recovery-phrase-confirm"]').click()
    # 确认
    wait(1)
    driver.find_element(By.CSS_SELECTOR, '[data-testid="onboarding-complete-done"]').click()
    # 下一步
    wait(1)
    driver.find_element(By.CSS_SELECTOR, '[data-testid="pin-extension-next"]').click()
    # 完成
    wait(1)
    driver.find_element(By.CSS_SELECTOR, '[data-testid="pin-extension-done"]').click()
    raw_data3 = {
        "browser_id": [browser_id],
        "meta_passwd": [meta_passwd],
        "meta_recovery": [meta_recovery]
    }
    data = pandas.DataFrame(raw_data3)
    if os.path.exists('../data/meta_result.csv'):
        data.to_csv("../data/meta_result.csv", mode='a', index=False, header=False)
    else:
        data.to_csv("../data/meta_result.csv", mode='a', index=False,
                    header=['browser_id', 'meta_passwd', 'meta_recovery'])
    # # 处理弹窗
    # wait(1)
    # driver.find_element(By.CLASS_NAME, 'whats-new-popup__button').click()
    # # 复制地址
    # wait(1)
    # driver.find_element(By.CSS_SELECTOR, '[data-testid="address-copy-button-text"]').click()
    print("窗口" + browser_id + '初始化完成')

#metamaskInit("a9275eb6f90c4ed5b39c520703001f8b")