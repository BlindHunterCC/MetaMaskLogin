import sys
import asyncio
from metamaskLogin import metamaskLogin
from asyncio.windows_events import WindowsSelectorEventLoopPolicy

sys.path.append('..')
from common.browser.bit_api import getBrowserListId

if __name__ == '__main__':
    browser = '9437ce45ade94ad3abc806253179f38a'
    asyncio.set_event_loop_policy(WindowsSelectorEventLoopPolicy())
    asyncio.run(metamaskLogin(browser))