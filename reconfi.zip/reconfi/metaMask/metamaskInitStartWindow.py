import sys
import asyncio
from metamaskInit import metamaskInit
from concurrent.futures import ThreadPoolExecutor


sys.path.append('..')
from common.browser.bit_api import getBrowserListId

from time import sleep


browser_list = getBrowserListId('2c9bc0618e1bf6dd018e224e487a1f67')

for browser in browser_list:
    # 打开太快了，电脑扛不住
    metamaskInit(browser)
    sleep(7)