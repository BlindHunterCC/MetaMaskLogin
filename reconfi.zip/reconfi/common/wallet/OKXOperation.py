from selenium.webdriver.common.by import By
from time import sleep


def okConfirmTx(driver, current_handle):
    sleep(5)
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if 'MetaMask Notification' in driver.title:
            windows = driver.window_handles
            driver.switch_to.window(windows[-1])
            sleep(1)
            # 钱包确认
            driver.find_element(By.CSS_SELECTOR, '[data-testid="page-container-footer-next"]').click()
            print('该tx已确认')
    driver.switch_to.window(current_handle)
def confirm_meta_tx(driver, current_handle):
    sleep(5)
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if 'MetaMask' in driver.title:
            windows = driver.window_handles
            driver.switch_to.window(windows[-1])
            sleep(1)
            # 钱包确认
            driver.find_element(By.CSS_SELECTOR, '[data-testid="page-container-footer-next"]').click()
            print('该tx已确认')
    driver.switch_to.window(current_handle)


def oKXConfirmSign(driver, current_handle):
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if 'OKX Wallet' in driver.title:
            windows = driver.window_handles
            driver.switch_to.window(windows[-1])
            # 钱包确认
            driver.find_element(By.XPATH, '//*[@id="app"]/div/div/div/div/div/div[5]/div/button[2]').click()
            print('okx签名已确认')
    driver.switch_to.window(current_handle)

def confirm_galxe_login(driver,current_handle):
    # 切换到metamask
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if 'MetaMask Notification' in driver.title:
            # 切换窗口，在弹出的窗口中输入密码
            windows = driver.window_handles
            driver.switch_to.window(windows[-1])
            # 向下滚动1000个像素
            driver.execute_script('var q=document.documentElement.scrollTop=5000')
            # 处理登录请求
            driver.find_element(By.CSS_SELECTOR, '[data-testid="page-container-footer-next"]').click()
    driver.switch_to.window(current_handle)

def confirm_mount(driver,current_handle,mount):
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if 'MetaMask Notification' in driver.title:
            windows = driver.window_handles
            driver.switch_to.window(windows[-1])
            # 设置支出上限
            sleep(2)
            driver.find_element(By.CSS_SELECTOR, '[data-testid="custom-spending-cap-input"]').send_keys(mount)
            sleep(2)
            # 下一步
            driver.find_element(By.CSS_SELECTOR, '[data-testid="page-container-footer-next"]').click()

            sleep(2)
            # 批准
            driver.find_element(By.CSS_SELECTOR, '[data-testid="page-container-footer-next"]').click()
            sleep(2)
    driver.switch_to.window(current_handle)