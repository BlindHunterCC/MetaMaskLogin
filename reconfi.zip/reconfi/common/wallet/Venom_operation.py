from selenium.webdriver.common.by import By
from time import sleep


def venom_confirm_tx(driver, current_handle,browser_id):
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if 'Venom' in driver.title:
            # 切换窗口，在弹出的窗口中输入密码
            windows = driver.window_handles
            driver.switch_to.window(windows[-1])
            # 获取密码输入框
            try:
                venom_pass_input = driver.find_element(By.CSS_SELECTOR, '[type="password"]')
                # 遍历DataFrame的每一行
                for index, row in cols.iterrows():
                    # row是一个pandas的Series对象，表示csv文件的一行数据
                    if row.get('browser_id') == browser_id:
                        venom_pass_input.send_keys(row.get('venom_passwd'))
                        break
                # 确认tx
                driver.find_element(By.XPATH, '//*[@id="root"]/div/div/div[2]/footer/div/button[2]').click()
                driver.switch_to.window(current_handle)
            except:
                print('venom确认tx失败.当前的浏览器id为：' + browser_id)
                driver.switch_to.window(current_handle)


def braavos_confirmSign(driver, current_handle,browser_id):
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if 'Braavos' in driver.title:
            windows = driver.window_handles
            driver.switch_to.window(windows[-1])
            # 钱包确认
            sleep(2)
            driver.find_element(By.CSS_SELECTOR, '[data-testid="page-container-footer-next"]').click()
            print('此Braavos 该签名已确认，当前的浏览器id为：'+browser_id)
        driver.switch_to.window(current_handle)
