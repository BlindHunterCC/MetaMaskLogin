from selenium.webdriver.common.by import By
from time import sleep
from selenium.webdriver.support import expected_conditions as EC

from selenium.webdriver.support.wait import WebDriverWait


def argent_confirm_tx(driver, current_handle):
        waitButton = WebDriverWait(driver, 6, 0.5)
        element = waitButton.until(EC.element_to_be_clickable((By.XPATH, '//*[@id="Confirm"]')))
        if element:
            # 钱包确认
            driver.find_element(By.XPATH, '//*[@id="Confirm"]').click()
            print('此Argent tx已确认')
        driver.switch_to.window(current_handle)


def argent_confirm_sign(driver, current_handle):
        element = WebDriverWait(driver, 6, 0.5).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="Sign"]')))
        if element:
            driver.find_element(By.XPATH, '//*[@id="Sign"]').click()
            print('此Argent 该签名已确认')
        driver.switch_to.window(current_handle)


def check_argent_login_status(driver, cols, browser_id, currentHandle):
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if 'ArgentX' == driver.title:
            # 切换窗口，在弹出的窗口中输入密码
            windows = driver.window_handles
            driver.switch_to.window(windows[-1])
            sleep(1)
            try:
                argentPassWdInput = driver.find_element(By.XPATH,
                                                        '//*[@id="root"]/div/div/div/div/div/div/div/div[2]/form/input')
                # 遍历DataFrame的每一行
                for index, row in cols.iterrows():
                    # row是一个pandas的Series对象，表示csv文件的一行数据
                    if row.get('browser_id') == browser_id:
                        argentPassWdInput.send_keys(row.get('argent_passwd'))
                        break
                sleep(1)
                # argent确认登录
                driver.find_element(By.XPATH,
                                    '//*[@id="root"]/div/div/div/div/div/div/div/div[2]/form/div/button').click()
            except:
                print('浏览器已打开，不需要ArgentX登录.当前的浏览器id为：' + browser_id)
            driver.switch_to.window(currentHandle)
            return True
