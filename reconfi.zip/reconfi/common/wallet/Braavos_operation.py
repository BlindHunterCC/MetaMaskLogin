from selenium.webdriver.common.by import By
from time import sleep
from selenium.webdriver.support import expected_conditions as EC

from selenium.webdriver.support.wait import WebDriverWait

def braavos_confirm_tx(driver, current_handle,browser_id):
    element = WebDriverWait(driver, 6).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="root"]/div/div/div/div/div/div/div/div/div/div[1]/div[2]/div[3]/div[4]/div[2]/div[2]/div')))
    if element:
        element.click()
        print('此Braavos 该签名已确认，当前的浏览器id为：'+browser_id)
    driver.switch_to.window(current_handle)



def braavos_confirm_sign(driver, current_handle,browser_id):
    element = WebDriverWait(driver, 6).until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'div.css-175oi2r>div.r-1otgn73:nth-child(2)>div:nth-child(2)')))
    if element:
        element.click()
        print('此Braavos 该签名已确认，当前的浏览器id为：'+browser_id)
    driver.switch_to.window(current_handle)

def check_braavos_login_status(driver, cols, browser_id, currentHandle):
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if 'Braavos' == driver.title:
            # 切换窗口，在弹出的窗口中输入密码
            windows = driver.window_handles
            driver.switch_to.window(windows[-1])
            sleep(1)
            try:
                # 获取密码输入框
                braavosPassWdInput = driver.find_element(By.XPATH,
                                                         '//*[@id="root"]/div/div/div/div[1]/div/div[2]/div/div/div/div[2]/div[2]/div[2]/div/input')
                # 遍历DataFrame的每一行
                for index, row in cols.iterrows():
                    # row是一个pandas的Series对象，表示csv文件的一行数据
                    if row.get('browser_id') == browser_id:
                        braavosPassWdInput.send_keys(row.get('braavos_passwd'))
                        break
                sleep(1)
                # braavos确认登录
                driver.find_element(By.XPATH,
                                    '//*[@id="root"]/div/div/div/div[1]/div/div[2]/div/div/div/div[2]/div[3]').click()
            except:
                print('浏览器已打开，不需要Braavos登录.当前的浏览器id为：' + browser_id)
            driver.switch_to.window(currentHandle)
            return True
