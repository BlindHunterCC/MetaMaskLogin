import os
import random
import string
from time import sleep

import pandas
import requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from random_words import LoremIpsum
from random_words import RandomWords
import pandas.io.clipboard as cb
from common.bit_api import openBrowser
from common.ads_api import openAdsBrowser
from common.commonUtils import generate_password
from common.commonUtils import open


def venom_init(browser_id, browser_type):
    driver = open(browser_id, browser_type)
    driver.get('chrome-extension://ojggmchlghnjlapmfbnjholfjkiidbch/home.html')
    sleep(3)
    # 选择创建新钱包
    driver.find_element(By.XPATH, '//*[@id="root"]/div[1]/div/div[2]/div/div/div[3]/div/div[1]').click()
    sleep(2)
    # 同意协议
    driver.find_element(By.XPATH, '//*[@id="root"]/div[1]/div/div[2]/div/div/div[2]/label/span').click()
    sleep(2)
    # Submit
    driver.find_element(By.XPATH, '//*[@id="root"]/div[1]/div/div[2]/div/div/div[3]/button[1]').click()
    sleep(1)
    # 点击Copy all words
    driver.find_element(By.XPATH, '//*[@id="root"]/div[1]/div/div[2]/div/div/button[2]').click()
    # 获取剪切板内容
    venom_recovery = cb.paste()
    print('当前浏览id为：' + browser_id +'  venom助记词:' + venom_recovery)
    # 点击 I wrote it down on paper
    driver.find_element(By.XPATH, '//*[@id="root"]/div[1]/div/div[2]/div/div/button[1]').click()
    sleep(2)
    recoveryList = venom_recovery.split(' ')
    div_list = driver.find_elements(By.XPATH,'//*[@id="words"]/div/div')
    for div in div_list:
        span_text = div.find_element(By.TAG_NAME,'span').text
        rec_order = int(span_text[:len(span_text)-1])
        print(rec_order)
        div.find_element(By.TAG_NAME, 'input').send_keys(recoveryList[rec_order-1])
        sleep(1)
    # 点击Comfirm
    driver.find_element(By.ID,'confirm').click()
    # 输入密码,生产八位随机密码
    venom_passwd = generate_password(8)
    print( 'browser_id为:'+browser_id+'的venom密码为：' + venom_passwd)
    passwdInput = driver.find_element(By.XPATH, '//*[@id="password"]/div[1]/input')
    passwdInput.send_keys(venom_passwd)
    sleep(1)
    # 确认密码
    confirmInput = driver.find_element(By.XPATH, '//*[@id="password"]/div[2]/input')
    confirmInput.send_keys(venom_passwd)
    # Create the wallet
    sleep(1)
    driver.find_element(By.XPATH, '//*[@id="root"]/div[1]/div/div[2]/div/div[2]/button[1]').click()
    # 完成
    raw_data3 = {
        "browser_id": [browser_id],
        "venom_passwd": [venom_passwd],
        "venom_recovery": [venom_recovery]
    }
    data = pandas.DataFrame(raw_data3)
    if os.path.exists('../data/venom_result.csv'):
        data.to_csv("../data/venom_result.csv", mode='a', index=False, header=False)
    else:
        data.to_csv("../data/venom_result.csv", mode='a', index=False,
                    header=['browser_id', 'venom_passwd', 'venom_recovery'])
    print("窗口" + browser_id + 'venom初始化完成')
def venom_interact(browser_id, browser_type):
    driver = open(browser_id, browser_type)
    driver.get('https://venom.network/tasks')
    sleep(8)
    cols = pandas.read_csv('../data/browser_info.csv', usecols=["browser_id", "venom_passwd"])
    # 获取任务列表
    task_list = driver.find_elements(By.XPATH, '//*[@id="ecosystem"]/div[2]')
    venom_passwd = ''
    # foundation
    mission_foundation(driver, task_list, cols, browser_id)
    # wallet
    mission_wallet(driver,task_list,cols,browser_id,venom_passwd)
def mission_foundation(driver,task_list,cols,browser_id):
    for task in task_list:
        sleep(1)
        # 获取链接，根据链接区分操作
        link = task.find_element(By.CLASS_NAME, 'btn')
        # 获取当前子任务页面的handle
        curent_handle = driver.current_window_handle
        link_text = link.get_attribute('href')
        # 第一个任务
        if 'foundation' in link_text:
            link.click()
            sleep(5)
            # 获取子任务列表
            steps = driver.find_elements(By.XPATH,'//*[@id="root"]/div[2]/section/div/div[2]/div[2]')
            for step in steps:
                step_description = step.find_element(By.TAG_NAME,'h4').text
                if 'Telegram' in step_description:
                    step.find_element(By.TAG_NAME, 'a').click()
                    sleep(3)
                    driver.close()
                    # 切换回任务页面，等待任务自动完成
                    driver.switch_to.window(curent_handle)
                if 'YouTube' in step_description:
                    step.find_element(By.TAG_NAME, 'a').click()
                    sleep(3)
                    driver.close()
                    # 切换回任务页面，等待任务自动完成
                    driver.switch_to.window(curent_handle)
            mint_button = driver.find_element(By.XPATH,'//*[@id="root"]/div[2]/section/div/div[2]/div[2]/div[3]/button')
            if mint_button.text == 'Mint':
                # mint
                mint_button.click()
                for handle in driver.window_handles:
                    driver.switch_to.window(handle)
                    if 'Venom' in driver.title:
                        # 切换窗口，在弹出的窗口中输入密码
                        windows = driver.window_handles
                        driver.switch_to.window(windows[-1])
                        # 获取密码输入框
                        try:
                            venom_pass_input = driver.find_element(By.CSS_SELECTOR, '[type="password"]')
                            # 遍历DataFrame的每一行
                            for index, row in cols.iterrows():
                                # row是一个pandas的Series对象，表示csv文件的一行数据
                                if row.get('browser_id') == browser_id:
                                    venom_passwd = row.get('venom_passwd')
                                    venom_pass_input.send_keys(row.get('venom_passwd'))
                                    break
                            # 确认tx
                            driver.find_element(By.XPATH, '//*[@id="root"]/div/div/div[2]/footer/div/button[2]').click()
                            driver.switch_to.window(curent_handle)
                            sleep(10)
                        except:
                            print('venom确认tx失败.当前的浏览器id为：' + browser_id)
                            driver.switch_to.window(curent_handle)
                driver.find_element(By.XPATH,'//*[@id="nft-1"]/a').click()
                sleep(4)
def web3_world_foundation(driver,task_list,cols,browser_id):
    for task in task_list:
        sleep(1)
        # 获取链接，根据链接区分操作
        link = task.find_element(By.CLASS_NAME, 'btn')
        # 获取当前子任务页面的handle
        curent_handle = driver.current_window_handle
        link_text = link.get_attribute('href')
        if 'web3-world' in link_text:
            link.click()
            sleep(5)
            # 获取子任务列表
            steps = driver.find_elements(By.XPATH,'//*[@id="root"]/div[2]/section/div/div[2]/div[2]')
            for step in steps:
                step_description = step.find_element(By.TAG_NAME,'h4').text
                if 'Telegram' in step_description:
                    step.find_element(By.TAG_NAME, 'a').click()
                    sleep(3)
                    driver.close()
                    # 切换回任务页面，等待任务自动完成
                    driver.switch_to.window(curent_handle)
                    sleep(3)
            # 获取刷新后的新页面
            steps = driver.find_elements(By.XPATH,'//*[@id="root"]/div[2]/section/div/div[2]/div[2]')
            for step in steps:
                step_description = step.find_element(By.TAG_NAME,'h4').text
                if 'Swap' in step_description:
                    step.find_element(By.TAG_NAME, 'a').click()
                    sleep(8)
                    # 切换到新窗口
                    windows = driver.window_handles
                    driver.switch_to.window(windows[-1])
                    # 连接钱包
                    driver.find_element(By.XPATH,'//*[@id="root"]/div[1]/main/div/div[2]/div[1]/div[2]/div[2]/div/button').click()

                    # 切换回任务页面，等待任务自动完成
                    driver.switch_to.window(curent_handle)
                    sleep(3)

            mint_button = driver.find_element(By.XPATH,'//*[@id="root"]/div[2]/section/div/div[2]/div[2]/div[3]/button')
            if mint_button.text == 'Mint':
                # mint
                mint_button.click()
                for handle in driver.window_handles:
                    driver.switch_to.window(handle)
                    if 'Venom' in driver.title:
                        # 切换窗口，在弹出的窗口中输入密码
                        windows = driver.window_handles
                        driver.switch_to.window(windows[-1])
                        # 获取密码输入框
                        try:
                            venom_pass_input = driver.find_element(By.CSS_SELECTOR, '[type="password"]')
                            # 遍历DataFrame的每一行
                            for index, row in cols.iterrows():
                                # row是一个pandas的Series对象，表示csv文件的一行数据
                                if row.get('browser_id') == browser_id:
                                    venom_passwd = row.get('venom_passwd')
                                    venom_pass_input.send_keys(row.get('venom_passwd'))
                                    break
                            # 确认tx
                            driver.find_element(By.XPATH, '//*[@id="root"]/div/div/div[2]/footer/div/button[2]').click()
                            driver.switch_to.window(curent_handle)
                            sleep(10)
                        except:
                            print('venom确认tx失败.当前的浏览器id为：' + browser_id)
                            driver.switch_to.window(curent_handle)
                driver.find_element(By.XPATH,'//*[@id="nft-1"]/a').click()
                sleep(4)

def mission_wallet(driver,task_list,cols,browser_id,venom_passwd):
    for task in task_list:
        sleep(1)
        # 获取链接，根据链接区分操作
        link = task.find_element(By.CLASS_NAME, 'btn')
        # 获取当前子任务页面的handle
        curent_handle = driver.current_window_handle
        link_text = link.get_attribute('href')
        # 第一个任务
        if 'wallet' in link_text:
            link.click()
            sleep(5)

            # 获取子任务列表
            steps = driver.find_elements(By.XPATH,'//*[@id="root"]/div[2]/section/div/div[2]/div[2]')
            for step in steps:
                step_description = step.find_element(By.TAG_NAME,'h4').text
                if 'Send' in step_description:
                    # 复制钱包地址
                    step.find_element(By.XPATH, '//*[@id="root"]/div[2]/section/div/div[2]/div[2]/div[1]/p/span').click()
                    to_address = cb.paste()
                    send_venom(driver,to_address,curent_handle,venom_passwd)
                    sleep(1)
                    # 切换回任务页面，等待任务自动完成
                    driver.switch_to.window(curent_handle)
                    # Check
                    step.find_element(By.XPATH,'//*[@id="root"]/div[2]/section/div/div[2]/div[2]/div[1]/button').click()
                    sleep(3)
            mint_button = driver.find_element(By.XPATH,'//*[@id="root"]/div[2]/section/div/div[2]/div[2]/div[3]/button')
            if mint_button.text == 'Mint':
                # mint
                mint_button.click()
                for handle in driver.window_handles:
                    driver.switch_to.window(handle)
                    if 'Venom' in driver.title:
                        # 切换窗口，在弹出的窗口中输入密码
                        windows = driver.window_handles
                        driver.switch_to.window(windows[-1])
                        # 获取密码输入框
                        try:
                            venom_pass_input = driver.find_element(By.CSS_SELECTOR, '[type="password"]')
                            # 遍历DataFrame的每一行
                            for index, row in cols.iterrows():
                                # row是一个pandas的Series对象，表示csv文件的一行数据
                                if row.get('browser_id') == browser_id:
                                    venom_pass_input.send_keys(row.get('venom_passwd'))
                                    break
                            # 确认tx
                            driver.find_element(By.XPATH, '//*[@id="root"]/div/div/div[2]/footer/div/button[2]').click()
                            driver.switch_to.window(curent_handle)
                            sleep(10)
                        except Exception as e:
                            print('venom确认tx失败.当前的浏览器id为：' + browser_id)
                            print(e)
                            driver.switch_to.window(curent_handle)
                # 返回
                driver.find_element(By.XPATH,'//*[@id="nft-1"]/a').click()
                sleep(4)

def send_venom(driver,address,curent_handle,venom_passwd):
    driver.get('chrome-extension://ojggmchlghnjlapmfbnjholfjkiidbch/popup.html')
    sleep(1)
    driver.find_element(By.XPATH,'//*[@id="root"]/div/div[1]/div[3]/button[2]').click()
    # 切换窗口
    windows = driver.window_handles
    driver.switch_to.window(windows[-1])
    # 填写收地址
    driver.find_element(By.XPATH,'//*[@id="receiver"]').send_keys(address)
    # 填写数量
    mount = round(random.uniform(0.1, 0.2), 2)
    driver.find_element(By.XPATH,'//*[@id="send"]/div[3]/div/input').send_keys(mount)
    # 填写密码
    driver.find_element(By.XPATH,'//*[@id="root"]/div/div[2]/div/div[2]/input').send_keys(venom_passwd)
    # 确认
    driver.find_element(By.XPATH,'//*[@id="root"]/div/div[2]/footer/div/button[2]').click()
    # 点击OK
    driver.find_element(By.XPATH, '//*[@id="root"]/div/div[2]/div/div[1]/footer/button').click()
    driver.switch_to.window(curent_handle)