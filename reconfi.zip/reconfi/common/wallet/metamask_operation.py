from selenium.webdriver.common.by import By
from time import sleep
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def confirm_tx(driver, current_handle):
    sleep(1)
    wait = WebDriverWait(driver, 1, 0.5)
    while True:
        for handle in driver.window_handles:
            driver.switch_to.window(handle)
            try:
                windowMetamask = wait.until(EC.title_is("MetaMask Notification"))
                if windowMetamask:
                    # 钱包确认
                    # while True:
                    # sleep(2)
                    waitButton = WebDriverWait(driver, 4, 0.5)
                    # confirmButton = driver.find_element(By.CSS_SELECTOR, '[data-testid="page-container-footer-next"]')
                    element = waitButton.until(EC.element_to_be_clickable((By.CSS_SELECTOR, '[data-testid="page-container-footer-next"]')), message="")
                    if element:
                        driver.find_element(By.CSS_SELECTOR, '[data-testid="page-container-footer-next"]').click()
                        # break
                        print('该tx已确认')
                        driver.switch_to.window(current_handle)
                    break
            except:
                continue

def confirm_meta_tx(driver, current_handle):
    sleep(1)
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if 'MetaMask' in driver.title:
            windows = driver.window_handles
            driver.switch_to.window(windows[-1])
            sleep(1)
            # 钱包确认
            driver.find_element(By.CSS_SELECTOR, '[data-testid="page-container-footer-next"]').click()
            print('该tx已确认')
    driver.switch_to.window(current_handle)


def confirmSign(driver, current_handle):
    sleep(1)
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if 'MetaMask Notification' in driver.title:
            # windows = driver.window_handles
            # driver.switch_to.window(windows[-1])
            # 钱包确认
            sleep(2)
            driver.find_element(By.CSS_SELECTOR, '[data-testid="page-container-footer-next"]').click()
            print('该签名已确认')
    driver.switch_to.window(current_handle)

def confirm_sign(driver, current_handle):
    wait = WebDriverWait(driver, 6, 0.5)
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '[data-testid="page-container-footer-next"]'))).click()
    except:
        driver.switch_to.window(current_handle)
        raise Exception('找不到签名button')
    print('该签名已确认')
    driver.switch_to.window(current_handle)

def confirm_network(driver, current_handle):
    wait = WebDriverWait(driver, 6, 0.5)
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '[data-testid="confirmation-submit-button"]'))).click()
    except:
        driver.switch_to.window(current_handle)
        raise Exception('不需要切换网络！')
    driver.switch_to.window(current_handle)

def confirm_galxe_login(driver,current_handle):
    # 切换到metamask
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if 'MetaMask Notification' in driver.title:
            # 切换窗口，在弹出的窗口中输入密码
            windows = driver.window_handles
            driver.switch_to.window(windows[-1])
            # 向下滚动1000个像素
            driver.execute_script('var q=document.documentElement.scrollTop=5000')
            # 处理登录请求
            driver.find_element(By.CSS_SELECTOR, '[data-testid="page-container-footer-next"]').click()
    driver.switch_to.window(current_handle)

def confirm_mount(driver,current_handle,mount):
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if 'MetaMask Notification' in driver.title:
            windows = driver.window_handles
            driver.switch_to.window(windows[-1])
            # 设置支出上限
            sleep(2)
            driver.find_element(By.CSS_SELECTOR, '[data-testid="custom-spending-cap-input"]').send_keys(mount)
            sleep(2)
            # 下一步
            driver.find_element(By.CSS_SELECTOR, '[data-testid="page-container-footer-next"]').click()

            sleep(2)
            # 批准
            driver.find_element(By.CSS_SELECTOR, '[data-testid="page-container-footer-next"]').click()
            sleep(2)
    driver.switch_to.window(current_handle)