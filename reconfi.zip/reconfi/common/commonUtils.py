import threading
import random
import string
import asyncio
import aiofiles
import pandas

event = threading.Event()

def wait(second):
    delay = round(random.uniform(0, 1), 2)
    event.wait(second + delay)

def generate_password(length):
    password = ''
    for i in range(length):
        # password += random.choice(string.ascii_letters + string.digits + string.punctuation)
        password += random.choice(string.ascii_letters + string.digits)
    return password

async def async_read_csv(file_path,usecols):
    async with aiofiles.open(file_path, mode='r') as f:
        # 使用异步读取文件内容
        content = await f.read()
        # 将内容转换为 Pandas DataFrame
        #df = pd.read_csv(io.StringIO(content))
        #df = pandas.read_csv('../data/browser_info.csv', usecols=["browser_id", "meta_passwd"])
        df = pandas.read_csv(file_path, usecols=usecols)
    return df