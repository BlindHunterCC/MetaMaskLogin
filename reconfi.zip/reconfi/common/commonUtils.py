import threading
import random
import string

event = threading.Event()

def wait(second):
    delay = round(random.uniform(0, 1), 2)
    event.wait(second + delay)

def generate_password(length):
    password = ''
    for i in range(length):
        # password += random.choice(string.ascii_letters + string.digits + string.punctuation)
        password += random.choice(string.ascii_letters + string.digits)
    return password