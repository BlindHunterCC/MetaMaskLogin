import json
import time
import asyncio
import requests
from curl_cffi.requests import AsyncSession
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service

# 官方文档地址
# https://doc2.bitbrowser.cn/jiekou/ben-di-fu-wu-zhi-nan.html

# 此demo仅作为参考使用，以下使用的指纹参数仅是部分参数，完整参数请参考文档

url = "http://127.0.0.1:54345"
headers = {'Content-Type': 'application/json'}


def createBrowser():  # 创建或者更新窗口，指纹参数 browserFingerPrint 如没有特定需求，只需要指定下内核即可，如果需要更详细的参数，请参考文档
    json_data = {
        # 'groupId': '2c996b378054663b01805a69f0344410', # 群组ID，绑定群组时传入，如果登录的是子账号，则必须赋值，否则会自动分配到主账户下面去
        'platform': 'https://www.facebook.com',  # 账号平台
        'platformIcon': 'facebook',  # 取账号平台的 hostname 或者设置为other
        'url': '',  # 打开的url，多个用,分开
        'name': 'google',  # 窗口名称
        'remark': '',  # 备注
        'userName': '',  # 用户账号
        'password': '',  # 用户密码
        'cookie': '',  # Cookie，符合标准的序列化字符串，具体可参考文档
        # IP库，默认ip-api，选项 ip-api | ip123in | luminati，luminati为Luminati专用
        'ipCheckService': 'ip-api',
        'proxyMethod': 2,  # 代理方式 2自定义 3 提取IP
        # 代理类型  ['noproxy', 'http', 'https', 'socks5', '911s5']
        'proxyType': 'noproxy',
        'host': '12.132.234.12',  # 代理主机
        'port': 99999,  # 代理端口
        'proxyUserName': '',  # 代理账号
        'proxyPassword': '',  # 代理密码
        'ip': '',  # ip
        'city': '',  # 城市
        'province': '',  # 州/省
        'country': '',  # 国家地区
        'dynamicIpUrl': '',  # 提取IP url，参考文档
        'dynamicIpChannel': '',  # 提取IP服务商，参考文档
        'isDynamicIpChangeIp': True,  # 提取IP方式，参考文档
        'isGlobalProxyInfo': False,  # 提取IP设置，参考文档
        'isIpv6': False,  # 是否是IP6
        'syncTabs': True,  # 同步标签页
        'syncCookies': True,  # 同步Cookie
        'syncIndexedDb': False,  # 同步IndexedDB
        'syncLocalStorage': False,  # 同步 Local Storage
        'syncBookmarks': True,  # 同步书签
        'credentialsEnableService': False,  # 禁止保存密码弹窗
        'syncHistory': False,  # 保存历史记录
        'clearCacheFilesBeforeLaunch': False,  # 启动前清理缓存文件
        'clearCookiesBeforeLaunch': False,  # 启动前清理cookie
        'clearHistoriesBeforeLaunch': False,  # 启动前清理历史记录
        'randomFingerprint': False,  # 每次启动均随机指纹
        # 浏览器窗口工作台页面，默认 chuhai2345,不展示填 disable 可选 chuhai2345 | localserver | disable
        'workbench': 'chuhai2345',
        'disableGpu': False,  # 关闭GPU硬件加速 False取反 默认 开启
        'enableBackgroundMode': False,  # 关闭浏览器后继续运行应用
        'disableTranslatePopup': False,  # 翻译弹窗
        'syncExtensions': False,  # 同步扩展应用数据
        'syncUserExtensions': False,  # 跨窗口同步扩展应用
        'allowedSignin': False,  # 允许google账号登录浏览器
        'abortImage': False,  # 禁止加载图片
        'abortMedia': False,  # 禁止视频自动播放
        'muteAudio': False,  # 禁止播放声音
        'stopWhileNetError': False,  # 网络不通停止打开
        "browserFingerPrint": {  # 指纹对象
            'coreVersion': '104'  # 内核版本 112 | 104，建议使用112，注意，win7/win8/winserver 2012 已经不支持112内核了，无法打开
        }
    }

    res = requests.post(f"{url}/browser/update",
                        data=json.dumps(json_data), headers=headers).json()
    browserId = res['data']['id']
    print(browserId)
    return browserId


def update_browser(browser_id):  # 更新窗口，支持批量更新和按需更新，ids 传入数组，单独更新只传一个id即可，只传入需要修改的字段即可，比如修改备注，具体字段请参考文档，browserFingerPrint指纹对象不修改，则无需传入
    json_data = {'ids': browser_id,
                 'url': '',
                 'browserFingerPrint': {}}
    res = requests.post(f"{url}/browser/update/partial",
                        data=json.dumps(json_data), headers=headers).json()
    print(res)

# 获取所有的浏览器窗口,返回浏览器id集合
def getBrowserListId(group_id):
    json_data = {"page": 0,
                 "pageSize": 100,
                 "groupId": group_id,
                 }
    res = requests.post(f"{url}/browser/list", data=json.dumps(json_data), headers=headers).json()
    browser_ids = []
    for idList in res['data']['list']:
        browser_ids.append(idList['id'])
    return browser_ids


def getBrowserList(group_id):
    json_data = {"page": 0,
                 "pageSize": 10,
                 "groupId": group_id,
                 }
    res = requests.post(f"{url}/browser/list", data=json.dumps(json_data), headers=headers).json()
    return res['data']['list']


# 直接指定ID打开窗口，也可以使用 createBrowser 方法返回的ID
async def openBrowser(id):
    json_data = {"id": f'{id}',
                 # "loadExtensions": False,
                 "queue": True,
                 "args": ['--disable-notifications']
                 }
    
    res =await AsyncSession(timeout=120,headers=headers).post(f"{url}/browser/open",data=json.dumps(json_data))
    #res =await asyncio.get_event_loop().run_in_executor(None,requests.post,f"{url}/browser/open",dict(json.dumps(json_data)), dict(headers))

    return res.json()


def getGroupList():
    json_data = {"page": 0,
                 "pageSize": 100
                 }
    res = requests.post(f"{url}/group/list", data=json.dumps(json_data), headers=headers).json()
    return res


# 分组详情
def getGroupDetail(id):
    json_data = {"id": id}
    res = requests.post(f"{url}/group/detail", data=json.dumps(json_data), headers=headers).json()
    return res


def closeBrowser(id):  # 关闭窗口
    json_data = {'id': f'{id}'}
    requests.post(f"{url}/browser/close", data=json.dumps(json_data), headers=headers).json()


def deleteBrowser(id):  # 删除窗口
    json_data = {'id': f'{id}'}
    print(requests.post(f"{url}/browser/delete", data=json.dumps(json_data), headers=headers).json())


if __name__ == '__main__':
    browser_id = 'd74974b112564956b0b487e194aad1c7'
    openBrowser(browser_id)

    time.sleep(10)  # 等待10秒自动关闭窗口

    closeBrowser(browser_id)

    time.sleep(10)  # 等待10秒自动删掉窗口

async def open(browser_id):
    driverPath = ''
    debuggerAddress = ''

    res = await openBrowser(browser_id)
    driverPath = res['data']['driver']
    debuggerAddress = res['data']['http']

    if driverPath is None or debuggerAddress is None:
        raise Exception('参数有误，请检查参数！')
    service = Service(executable_path=driverPath)
    chrome_options = Options()
    chrome_options.add_experimental_option("debuggerAddress", debuggerAddress)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    # 隐式等待:如果找不到元素， 每隔 半秒钟 再去界面上查看一次， 直到找到该元素， 或者 过了10秒 最大时长。
    # driver.implicitly_wait(15)
    return driver